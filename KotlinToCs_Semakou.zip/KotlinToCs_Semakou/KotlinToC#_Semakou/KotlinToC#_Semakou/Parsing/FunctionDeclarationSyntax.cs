﻿using KotlinToCs_Semakou.Lexing;
using System.Collections.Generic;

namespace KotlinToCs_Semakou.Parsing
{
    class FunctionDeclarationSyntax : ExpressionSyntax
    {
        public override SyntaxKind Kind => SyntaxKind.FunctionDeclaration;
        public SyntaxToken Identifier { get; }
        public IReadOnlyList<ParameterSyntax> Parameters { get; }
        public BlockSyntax Body { get; }

        public FunctionDeclarationSyntax(SyntaxToken identifier, IReadOnlyList<ParameterSyntax> parameters, BlockSyntax body)
        {
            Identifier = identifier;
            Parameters = parameters;
            Body = body;
        }

        public override IEnumerable<SyntaxNode> GetChildren()
        {
            yield return Identifier;
            foreach (var parameter in Parameters)
            {
                yield return parameter;
            }
            yield return Body;
        }
    }
}
