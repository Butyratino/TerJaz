﻿using KotlinToCs_Semakou.Lexing;
using System.Collections.Generic;

namespace KotlinToCs_Semakou.Parsing
{
    class MatrixDeclarationSyntax : ExpressionSyntax
    {
        public override SyntaxKind Kind => SyntaxKind.MatrixDeclaration;
        public SyntaxToken Identifier { get; }
        public SyntaxToken TypeIdentifier { get; }
        public ExpressionSyntax RowsExpression { get; }
        public ExpressionSyntax ColumnsExpression { get; }

        public MatrixDeclarationSyntax(SyntaxToken typeIdentifier, SyntaxToken identifier, ExpressionSyntax rowsExpression, ExpressionSyntax columnsExpression)
        {
            TypeIdentifier = typeIdentifier;
            Identifier = identifier;
            RowsExpression = rowsExpression;
            ColumnsExpression = columnsExpression;
        }

        public override IEnumerable<SyntaxNode> GetChildren()
        {
            yield return TypeIdentifier;
            yield return Identifier;
            yield return RowsExpression;
            yield return ColumnsExpression;
        }
    }
}
