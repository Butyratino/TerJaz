﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KotlinToCs_Semakou.Interpreting
{
    class MatrixType
    {
        public List<List<object>> Elements { get; }

        public MatrixType(int rows, int columns)
        {
            Elements = new List<List<object>>();
            for (int i = 0; i < rows; i++)
            {
                Elements.Add(new List<object>(new object[columns]));
            }
        }
    }
}

