﻿using KotlinToCs_Semakou.Lexing;

namespace KotlinToCs_Semakou.Interpreting
{
    internal abstract class TypedValue
    {
        public Context Context { get; set; } = null;
        public SyntaxKind Type { get; set; }
    }
}