﻿using KotlinToCs_Semakou.Interpreting;
using KotlinToCs_Semakou.Lexing;
using System;

class IntValue : TypedValue
{
    public int Value { get; private set; }

    public IntValue(int value)
    {
        Value = value;
        Type = SyntaxKind.IntToken;
    }

    public IntValue(int value, Context context) : this(value)
    {
        Context = context;
    }

    public override string ToString()
    {
        return Value.ToString();
    }

    public IntValue Add(IntValue n)
    {
        return new IntValue(Value + n.Value, Context);
    }

    public IntValue Subtract(IntValue n)
    {
        return new IntValue(Value - n.Value, Context);
    }

    public IntValue Multiply(IntValue n)
    {
        return new IntValue(Value * n.Value, Context);
    }

    public IntValue Divide(IntValue n)
    {
        // Assuming division by zero is handled elsewhere
        return new IntValue(Value / n.Value, Context);
    }

    public IntValue Comparison_NotEquals(IntValue n)
    {
        return new IntValue(Value != n.Value ? 1 : 0, Context);
    }

    public IntValue Comparison_Equals(IntValue n)
    {
        return new IntValue(Value == n.Value ? 1 : 0, Context);
    }

    public IntValue Comparison_Less(IntValue n)
    {
        return new IntValue(Value < n.Value ? 1 : 0, Context);
    }

    public IntValue Comparison_LessEquals(IntValue n)
    {
        return new IntValue(Value <= n.Value ? 1 : 0, Context);
    }

    public IntValue Comparison_Greater(IntValue n)
    {
        return new IntValue(Value > n.Value ? 1 : 0, Context);
    }

    public IntValue Comparison_GreaterEquals(IntValue n)
    {
        return new IntValue(Value >= n.Value ? 1 : 0, Context);
    }

    public bool IsTrue()
    {
        return Value != 0;
    }
}
