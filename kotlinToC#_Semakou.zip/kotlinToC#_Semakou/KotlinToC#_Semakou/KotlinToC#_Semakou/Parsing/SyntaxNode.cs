﻿using KotlinToCs_Semakou.Lexing;

namespace KotlinToCs_Semakou.Parsing
{
    abstract class SyntaxNode
    {
        public abstract SyntaxKind Kind { get; }        
    }
}
