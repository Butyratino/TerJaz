﻿using KotlinToCs_Semakou.Lexing;
using System.Collections.Generic;

namespace KotlinToCs_Semakou.Parsing
{
    class ArrayDeclarationSyntax : ExpressionSyntax
    {
        public override SyntaxKind Kind => SyntaxKind.ArrayDeclaration;
        public SyntaxToken Identifier { get; }
        public SyntaxToken TypeIdentifier { get; }
        public ExpressionSyntax SizeExpression { get; }

        public ArrayDeclarationSyntax(SyntaxToken typeIdentifier, SyntaxToken identifier, ExpressionSyntax sizeExpression)
        {
            TypeIdentifier = typeIdentifier;
            Identifier = identifier;
            SizeExpression = sizeExpression;
        }

        public override IEnumerable<SyntaxNode> GetChildren()
        {
            yield return TypeIdentifier;
            yield return Identifier;
            yield return SizeExpression;
        }
    }
}
