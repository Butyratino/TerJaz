﻿using KotlinToCs_Semakou.Lexing;

namespace KotlinToCs_Semakou.Parsing
{
    class ParameterSyntax : ExpressionSyntax
    {
        public override SyntaxKind Kind => SyntaxKind.Parameter;
        public SyntaxToken Identifier { get; }

        public ParameterSyntax(SyntaxToken identifier)
        {
            Identifier = identifier;
        }

        public override IEnumerable<SyntaxNode> GetChildren()
        {
            yield return Identifier;
        }
    }
}
