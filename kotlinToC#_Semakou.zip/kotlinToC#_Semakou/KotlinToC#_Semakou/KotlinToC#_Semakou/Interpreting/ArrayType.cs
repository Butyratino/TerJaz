﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KotlinToCs_Semakou.Interpreting
{
    class ArrayType
    {
        public object[] Elements { get; }

        public ArrayType(int size)
        {
            Elements = new object[size];
        }

        
    }
}
